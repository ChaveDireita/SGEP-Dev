namespace SGEP.Models
{
    public enum EstadoProjeto
    {
        Andamento,
        Finalizado
    }
}
